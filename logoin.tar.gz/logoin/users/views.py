from django.shortcuts import render
from .models import User
from django.http import HttpResponse


# Create your views here.

def index(reqeust):
    name = reqeust.POST.get('FirstName', '无')
    last_name = reqeust.POST.get('LastName', '无')
    emaill = reqeust.POST.get('EmailAddress', '无')
    user_name = reqeust.POST.get('UserName', '无')
    password = reqeust.POST.get('Password', '无')
    # pwd = reqeust.POST.get('Confirm Password', '无')
    User.objects.create(name=name, last_name=last_name, emaill=emaill, user_name=user_name, password=password)
    # if password == pwd:
    #     return render(reqeust, 'index.html')
    # else:
    #     return HttpResponse('不一样')
    return render(reqeust,'index.html')

def dl(request):
    user=User.objects.all()
    uname = request.POST['UserName']
    upwd = request.POST['Password']
    if upwd == upwd:
        return HttpResponse('成功')
    else:
        return HttpResponse('失败')
    